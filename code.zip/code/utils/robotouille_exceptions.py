class RobotouilleMalformedActionException(Exception):
    pass

class RobotouilleInvalidActionException(Exception):
    pass

class RobotouilleEnvironmentDoesNotExistException(Exception):
    pass